# airfx
Max objects ported from the open source VST2 [airwindows](https://github.com/airwindows/airwindows/) plugins by Chris Johnson. 

Releases and pre-release packages for all platforms are available from the GitHub releases page. Download and unzip into your Max Packages directory.


# License

This project and the Airwindows VSTs are licenced under the MIT license.
